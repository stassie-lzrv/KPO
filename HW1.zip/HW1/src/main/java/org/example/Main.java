package org.example;


public class Main {
    public static void main(String[] args) {
        Programmer programmer1 = new Programmer("Sam", 50000, 8);
        Secretary secretary1 = new Secretary("Lily", 3000, true);
        Secretary.initArray();
        Manager manager1 = new Manager("John", 10000, 5, "bank");
        Manager manager2 = new Manager("John", 10000, 5, "science");
        Executive executive1 = new Executive("Pasha", 50000, 15, "bank", manager1);
        Employee[] employees = {programmer1, secretary1, manager1, manager2, executive1};
        executive1.addSubordinate(manager2);
        for (Employee employee : employees
        ) {
            if (employee instanceof Programmer) {
                ((Programmer) employee).code();
            } else if (employee instanceof Secretary) {
                ((Secretary) employee).doPaperWork(2);
            } else if (employee instanceof Manager manager) {
                if (manager instanceof Executive) {
                    ((Executive) manager).beAngry();
                } else {
                    manager.work();
                }
            }
            ((IUpgradable) employee).upgrade();
            employee.display();
        }

    }
}


