package org.example;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Executive extends Manager implements IUpgradable {

    private ArrayList<Manager> subordinates = new ArrayList<>();

    public void getSubordinates() {
        System.out.print("Subordinates:\n");
        for (Manager manager : subordinates
        ) {
            System.out.printf("%s\n", manager);
        }
    }

    public void addSubordinate(Manager manager) {
        subordinates.add(manager);
    }

    public void beAngry() {
        System.out.print("Executive is angry!\n");
    }

    public Executive(String name, int wage, int level, String department, Manager subordinate) {
        super(name, wage, level, department);
        this.subordinates.add(subordinate);
    }

    public void display() {
        System.out.printf("Position: Executive \t Name: %s \t Wage: %s\tNumber of subordinates: %s \n", super.getName(), super.getWage(), subordinates.size());
    }

    @Override
    public void upgrade() {
        if (subordinates.size() > 2) {
            this.doubleWage();
        }
    }
}
