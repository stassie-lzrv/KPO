package org.example;

public interface IUpgradable {
    void upgrade();
}
