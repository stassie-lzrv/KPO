package org.example;

public abstract class Employee {
    private final String name;
    private int wage;


    public String getName() {
        return name;
    }

    protected void doubleWage() {
        wage *= 2;
    }

    public int getWage() {
        return wage;
    }

    public Employee(String name, int wage) {
        this.name = name;
        this.wage = wage;
    }

    public abstract void display();
}



