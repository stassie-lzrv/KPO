package org.example;

import java.sql.Array;
import java.util.ArrayList;

public class Secretary extends Employee implements IUpgradable {

    private final boolean canDoPaperWork;

    public static ArrayList<String> documentNames;

    void doPaperWork(int documentNumber) {
        if (!canDoPaperWork) {
            System.out.println("Secretary can't do paper work\n");
        } else {
            try {
                System.out.printf("Secretary is working with document %s\n", documentNames.get(documentNumber - 1));
                documentNames.remove(documentNumber - 1);
            } catch (IndexOutOfBoundsException ex) {
                System.out.print("Invalid index\n");
            }
        }
    }

    public static void initArray() {
        documentNames = new ArrayList<>();
        documentNames.add("meow");
        documentNames.add("meow1");
        documentNames.add("meow2");
        documentNames.add("meow3");
    }


    public Secretary(String name, int wage, boolean canDoPaperWork) {
        super(name, wage);
        this.canDoPaperWork = canDoPaperWork;
    }

    @Override
    public void display() {
        System.out.printf("Position: Secretary \t Name: %s \t Wage: %s\t Can do paper work: %s \n", super.getName(), super.getWage(), canDoPaperWork);
    }

    @Override
    public void upgrade() {
        if (documentNames.isEmpty()) {
            this.doubleWage();
        }
    }
}
