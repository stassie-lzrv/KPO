package org.example;

public class Programmer extends Employee implements IUpgradable {

    private final int shiftLength;

    public Programmer(String name, int wage, int shiftLength) {
        super(name, wage);
        this.shiftLength = shiftLength;
    }

    public void code() {
        System.out.printf("Programmer %s is coding for %s hours\n", getName(), shiftLength);
    }

    @Override
    public void display() {
        System.out.printf("Position: Programmer \tName: %s \tWage: %s \tShift length: %s \n", super.getName(), super.getWage(), shiftLength);
    }

    @Override
    public void upgrade() {
        if (shiftLength > 6) {
            this.doubleWage();
        }
    }
}
