package org.example;


public class Manager extends Employee implements IUpgradable {
    private final int level;

    private final String department;

    public Manager(String name, int wage, int level, String department) {
        super(name, wage);
        this.level = level;
        this.department = department;
    }

    public void work() {
        System.out.printf("Manager is busy working in the %s department\n", department);
    }


    @Override
    public void display() {
        System.out.printf("Position: manager from %s department \tName: %s \tWage: %s\tLevel: %s \n", department, super.getName(), super.getWage(), level);
    }

    @Override
    public void upgrade() {
        if (department.equals("bank")) {
            this.doubleWage();
        }
    }
}